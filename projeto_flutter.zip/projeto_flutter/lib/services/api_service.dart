import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;

import '../models/disciplina.dart';
import '../models/usuario.dart';
import '../models/estudante.dart';
import '../models/prova.dart';
import '../models/gabarito.dart';
import '../models/turma.dart';
import '../models/resultado.dart';
import '../telas/tela_consulta_resultados.dart';
import '../utilidade/constants.dart';
import 'storage_service.dart';

class ApiService {
  static Map<String, String> get _authHeaders {
    final token = StorageService.getUserToken();
    final headers = Map<String, String>.from(ApiConstants.headers);

    if (token != null && token.isNotEmpty) {
      headers['Authorization'] = 'Bearer $token';
    }

    return headers;
  }

  static Future<Usuario?> login(String username, String password) async {
    try {
      final response = await http.post(
        Uri.parse("${ApiConstants.baseUrl}/auth/login"),
        headers: ApiConstants.headers,
        body: jsonEncode({
          "username": username,
          "password": password,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return Usuario.fromJson(data);
      }

      return null;
    } catch (e) {
      print("Erro no login: $e");
      return null;
    }
  }

  static Future<List<Disciplina>> obterMateriasProfessor(int professorId) async {
    try {
      final response = await http.get(
        Uri.parse("${ApiConstants.baseUrl}/disciplinas/professor/$professorId"),
        headers: _authHeaders,
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.map((json) => Disciplina.fromJson(json)).toList();
      }

      return [];
    } catch (e) {
      print("Erro ao obter matérias: $e");
      return [];
    }
  }

  static Future<List<Turma>> obterTurmasMateria(int disciplinaId) async {
    try {
      final response = await http.get(
        Uri.parse("${ApiConstants.baseUrl}/turmas/disciplina/$disciplinaId"),
        headers: _authHeaders,
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.map((json) => Turma.fromJson(json)).toList();
      }

      return [];
    } catch (e) {
      print("Erro ao obter turmas: $e");
      return [];
    }
  }

  Future<List<Prova>> getExams() async {
    try {
      final response = await http.get(
        Uri.parse("${ApiConstants.baseUrl}/provas"),
        headers: _authHeaders,
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.map((json) => Prova.fromJson(json)).toList();
      }

      return [];
    } catch (e) {
      print("Erro ao obter provas: $e");
      return [];
    }
  }

  Future<bool> saveGabarito(Gabarito gabarito) async {
    try {
      final response = await http.post(
        Uri.parse("${ApiConstants.baseUrl}/gabaritos"),
        headers: _authHeaders,
        body: jsonEncode(gabarito.toJson()),
      );

      return response.statusCode == 200 || response.statusCode == 201;
    } catch (e) {
      print("Erro ao salvar gabarito: $e");
      return false;
    }
  }

  Future<List<MediaTurma>> obterResultadosTurmas(int professorId) async {
    try {
      final response = await http.get(
        Uri.parse("${ApiConstants.baseUrl}/resultados/professor/$professorId"),
        headers: _authHeaders,
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.map((json) => MediaTurma.fromJson(json)).toList();
      }

      return [];
    } catch (e) {
      print("Erro ao obter resultados: $e");
      return [];
    }
  }

  Future<List<Estudante>> obterTodosAlunos() async {
    try {
      final response = await http.get(
        Uri.parse("${ApiConstants.baseUrl}/alunos"),
        headers: _authHeaders,
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.map((json) => Estudante.fromJson(json)).toList();
      }

      return [];
    } catch (e) {
      print("Erro ao obter todos os alunos: $e");
      return [];
    }
  }

  Future<List<Estudante>> obterAlunosTurma(int turmaId) async {
    try {
      final response = await http.get(
        Uri.parse("${ApiConstants.baseUrl}/alunos/turma/$turmaId"),
        headers: _authHeaders,
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.map((json) => Estudante.fromJson(json)).toList();
      }

      return [];
    } catch (e) {
      print("Erro ao obter alunos: $e");
      return [];
    }
  }
}
