import 'dart:io';
import 'package:flutter/material.dart';
import 'package:gabarito_app/models/disciplina.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/estudante.dart';
import '../models/turma.dart';
import '../models/prova.dart';
import '../models/gabarito.dart';
import '../services/api_service.dart';
import '../services/ocr_service.dart';
import '../utilidade/ThemeData.dart';
import '../widgets/botao_personalizado.dart';
import '../widgets/tela_loading.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:open_file/open_file.dart';

class GabaritoProva extends StatefulWidget {
  final Estudante estudante;
  final Disciplina disciplina;
  final Turma? turma;

  const GabaritoProva({
    Key? key,
    required this.estudante,
    required this.disciplina,
    this.turma,
  }) : super(key: key);

  @override
  State<GabaritoProva> createState() => _GabaritoProvaState();
}

class _GabaritoProvaState extends State<GabaritoProva> {
  List<Prova> _provas = [];
  Prova? _provaSelecionada;
  List<Gabarito> _gabaritos = [];
  bool _carregando = true;
  bool _enviando = false;
  bool _processandoOcr = false;
  String? _erroMensagem;
  File? _imagemCapturada;

  @override
  void initState() {
    super.initState();
    _carregarProvas();
  }

  Future<void> _carregarProvas() async {
    setState(() {
      _carregando = true;
      _erroMensagem = null;
    });

    try {
      final provas = await ApiService().getExams();
      setState(() {
        _provas = provas;
        _carregando = false;
      });
    } catch (e) {
      setState(() {
        _erroMensagem = 'Erro ao carregar provas: $e';
        _carregando = false;
      });
    }
  }

  void _selecionarProva(Prova prova) {
    setState(() {
      _provaSelecionada = prova;
      _gabaritos = List.generate(
        prova.questoes.length,
            (index) => Gabarito(
          questao: index + 1,
          resposta: '',
          estudanteId: widget.estudante.id,
          provaId: prova.id,
        ),
      );
    });
  }

  void _atualizarResposta(int questao, String resposta) {
    setState(() {
      final index = _gabaritos.indexWhere((g) => g.questao == questao);
      if (index != -1) {
        _gabaritos[index] = _gabaritos[index].copyWith(resposta: resposta);
      }
    });
  }

  Future<void> _capturarGabarito() async {
    final cameraStatus = await Permission.camera.request();
    final storageStatus = await Permission.storage.request();
    if (!cameraStatus.isGranted || !storageStatus.isGranted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Permissões necessárias não concedidas.'), backgroundColor: Colors.red),
      );
      return;
    }

    setState(() {
      _processandoOcr = true;
    });

    try {
      final resultado = await OcrService.capturarEProcessarGabarito();
      if (resultado != null) {
        setState(() {
          _imagemCapturada = resultado['imagem'];
        });

        final respostasDetectadas = resultado['respostas'] as Map<int, String>;
        final precisao = resultado['precisao'] as double;

        for (final entry in respostasDetectadas.entries) {
          if (entry.key <= _gabaritos.length) {
            _atualizarResposta(entry.key, entry.value);
          }
        }

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'OCR processado! ${respostasDetectadas.length} respostas detectadas '
                  '(Precisão: ${(precisao * 100).toStringAsFixed(1)}%)',
            ),
            backgroundColor: precisao > 0.7 ? Colors.green : Colors.orange,
            duration: const Duration(seconds: 4),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Nenhuma resposta foi detectada na imagem')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro no OCR: $e'), backgroundColor: Colors.red),
      );
    } finally {
      setState(() {
        _processandoOcr = false;
      });
    }
  }

  Future<void> _salvarGabarito() async {
    if (_provaSelecionada == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Selecione uma prova primeiro')),
      );
      return;
    }

    final respostasPreenchidas = _gabaritos.where((g) => g.resposta.isNotEmpty).length;
    if (respostasPreenchidas == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Preencha pelo menos uma resposta')),
      );
      return;
    }

    setState(() {
      _enviando = true;
    });

    try {
      bool todosSalvos = true;
      for (final gabarito in _gabaritos) {
        if (gabarito.resposta.isNotEmpty) {
          final sucesso = await ApiService().saveGabarito(gabarito);
          if (!sucesso) {
            todosSalvos = false;
            break;
          }
        }
      }

      if (todosSalvos) {
        await _gerarPDF();
        Navigator.of(context).pop();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Erro ao salvar algumas respostas')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao salvar gabarito: $e')),
      );
    } finally {
      setState(() {
        _enviando = false;
      });
    }
  }

  Future<void> _gerarPDF() async {
    final pdf = pw.Document();

    pdf.addPage(pw.Page(
      build: (pw.Context context) {
        return pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text('Gabarito Corrigido', style: const pw.TextStyle(fontSize: 18)),
            pw.SizedBox(height: 20),
            pw.Text('Disciplina: ${widget.disciplina.nome}'),
            pw.Text('Turma: ${widget.turma?.nome ?? 'N/A'}'),
            pw.Text('Aluno: ${widget.estudante.usuario.nome}'),
            pw.Text('RA: ${widget.estudante.id}'),
            pw.SizedBox(height: 20),
            pw.Table.fromTextArray(
              headers: ['Questão', 'Resposta'],
              data: _gabaritos.map((g) => [g.questao.toString(), g.resposta]).toList(),
            )
          ],
        );
      },
    ));

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/gabarito_${widget.estudante.id}.pdf');
    await file.writeAsBytes(await pdf.save());
    OpenFile.open(file.path);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Gabarito da Prova')),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            color: Colors.blue[50],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Disciplina: ${widget.disciplina.nome}', style: const TextStyle(fontSize: 14)),
                if (widget.turma != null) Text('Turma: ${widget.turma!.nome}'),
                Text('Aluno: ${widget.estudante.usuario.nome}'),
                Text('RA: ${widget.estudante.id}'),
              ],
            ),
          ),
          Expanded(child: _construirConteudo()),
        ],
      ),
    );
  }

  Widget _construirConteudo() {
    if (_carregando) return const LoadingWidget(message: 'Carregando provas...');
    if (_erroMensagem != null) {
      return Center(child: Text(_erroMensagem!));
    }
    if (_provas.isEmpty) {
      return const Center(child: Text('Nenhuma prova disponível.'));
    }
    if (_provaSelecionada == null) {
      return _construirSelecaoProva();
    }
    return _construirFormularioGabarito();
  }

  Widget _construirSelecaoProva() {
    return ListView.builder(
      itemCount: _provas.length,
      itemBuilder: (context, index) {
        final prova = _provas[index];
        return Card(
          child: ListTile(
            title: Text('Prova de ${prova.disciplina.nome}'),
            subtitle: Text('${prova.questoes.length} questões'),
            onTap: () => _selecionarProva(prova),
          ),
        );
      },
    );
  }

  Widget _construirFormularioGabarito() {
    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          color: Colors.green[50],
          child: Text('Prova de ${_provaSelecionada!.disciplina.nome}'),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: CustomButton(
                  text: _processandoOcr ? 'Processando...' : 'Capturar Gabarito',
                  onPressed: _processandoOcr ? null : _capturarGabarito,
                  backgroundColor: Colors.orange,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: CustomButton(
                  text: _enviando ? 'Salvando...' : 'Salvar e Gerar PDF',
                  onPressed: _enviando ? null : _salvarGabarito,
                  backgroundColor: Colors.green,
                ),
              ),
            ],
          ),
        ),
        if (_imagemCapturada != null)
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            height: 120,
            child: Image.file(_imagemCapturada!, fit: BoxFit.cover),
          ),
        Expanded(
          child: ListView.builder(
            itemCount: _gabaritos.length,
            itemBuilder: (context, index) {
              final gabarito = _gabaritos[index];
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                    Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Center(
                      child: Text(
                        '${gabarito.questao}',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Row(
                      children: ['A', 'B', 'C', 'D', 'E'].map((opcao) {
                        final selecionada = gabarito.resposta == opcao;
                        return Expanded(
                          child: GestureDetector(
                            onTap: () => _atualizarResposta(gabarito.questao, opcao),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              decoration: BoxDecoration(
                                color: selecionada ? Colors.blue : Colors.grey[200],
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                opcao,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: selecionada ? Colors.white : Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  )],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}