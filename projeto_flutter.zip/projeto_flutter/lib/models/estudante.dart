import 'package:gabarito_app/models/turma.dart';
import 'package:gabarito_app/models/usuario.dart';


class Estudante {
  final int id;
  final Usuario usuario;
  final Turma turma;

  Estudante({
    required this.id,
    required this.usuario,
    required this.turma,
  });

  factory Estudante.fromJson(Map<String, dynamic> json) {
    return Estudante(
      id: json['id'] ?? 0,
      usuario: Usuario.fromJson(json['usuario']),
      turma: Turma.fromJson(json['turma']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'usuario': usuario.toJson(),
      'turma': turma.toJson(),
    };
  }

  @override
  String toString() => usuario.nome;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Estudante && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;

  get nome => null;


}


