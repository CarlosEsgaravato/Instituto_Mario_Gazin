import 'disciplina.dart';
import 'estudante.dart';

class Turma {
  final int id;
  final String nome;
  final List<Disciplina> disciplinas;
  final List<Estudante> alunos;

  Turma({
    required this.id,
    required this.nome,
    required this.disciplinas,
    required this.alunos,
  });

  factory Turma.fromJson(Map<String, dynamic> json) {
    var disciplinasJson = json['disciplinas'] as List? ?? [];
    List<Disciplina> disciplinas = disciplinasJson
        .map((disciplina) => Disciplina.fromJson(disciplina))
        .toList();

    var alunosJson = json['alunos'] as List? ?? [];
    List<Estudante> alunos = alunosJson
        .map((aluno) => Estudante.fromJson(aluno))
        .toList();

    return Turma(
      id: json['id'] ?? 0,
      nome: json['nome'] ?? '',
      disciplinas: disciplinas,
      alunos: alunos,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nome': nome,
      'disciplinas': disciplinas.map((d) => d.toJson()).toList(),
      'alunos': alunos.map((a) => a.toJson()).toList(),
    };
  }

  // Campos calculados para uso nas telas
  String get periodo => nome.isNotEmpty ? nome[0] : 'T';
  int get semestre => id % 2 == 0 ? 2 : 1;
  int get ano => DateTime.now().year;
  int get totalAlunos => alunos.length;

  @override
  String toString() => '$nome ($id)';

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
          other is Turma && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;
}