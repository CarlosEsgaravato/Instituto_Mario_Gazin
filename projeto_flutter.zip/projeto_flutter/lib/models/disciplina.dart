import 'package:gabarito_app/models/professor.dart';
import 'package:gabarito_app/models/turma.dart';


class Disciplina {
  final int id;
  final String nome;
  final Turma turma;
  final Professor professor;

  Disciplina({
    required this.id,
    required this.nome,
    required this.turma,
    required this.professor,
  });

  factory Disciplina.fromJson(Map<String, dynamic> json) {
    return Disciplina(
      id: json['id'] ?? 0,
      nome: json['nome'] ?? '',
      turma: Turma.fromJson(json['turma']),
      professor: Professor.fromJson(json['professor']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nome': nome,
      'turma': turma.toJson(),
      'professor': professor.toJson(),
    };
  }

  @override
  String toString() => nome;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Disciplina && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;
}


