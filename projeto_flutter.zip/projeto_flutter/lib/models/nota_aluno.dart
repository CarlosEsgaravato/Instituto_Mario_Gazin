// models/nota_aluno.dart

class NotaAluno {
  final int alunoId;
  final String nomeAluno;
  final double nota;

  NotaAluno({
    required this.alunoId,
    required this.nomeAluno,
    required this.nota,
  });

  // ⚠️ INTEGRAÇÃO COM API JAVA: Ajuste os campos conforme o JSON retornado pela sua API
  factory NotaAluno.fromJson(Map<String, dynamic> json) {
    return NotaAluno(
      alunoId: json["alunoId"] ?? 0,
      nomeAluno: json["nomeAluno"] ?? "",
      nota: (json["nota"] ?? 0.0).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "alunoId": alunoId,
      "nomeAluno": nomeAluno,
      "nota": nota,
    };
  }
}

