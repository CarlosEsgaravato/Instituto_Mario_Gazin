class TipoUsuario {
  final int id;
  final String descricao;

  TipoUsuario({
    required this.id,
    required this.descricao,
  });

  factory TipoUsuario.fromJson(Map<String, dynamic> json) {
    return TipoUsuario(
      id: json["id"] ?? 0,
      descricao: json["descricao"] ?? "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "descricao": descricao,
    };
  }

  @override
  String toString() => descricao;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is TipoUsuario && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;
}


