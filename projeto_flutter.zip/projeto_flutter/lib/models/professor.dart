import 'package:gabarito_app/models/usuario.dart';

class Professor {
  final int id;
  final Usuario usuario;

  Professor({
    required this.id,
    required this.usuario,
  });

  factory Professor.fromJson(Map<String, dynamic> json) {
    return Professor(
      id: json['id'] ?? 0,
      usuario: Usuario.fromJson(json['usuario']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'usuario': usuario.toJson(),
    };
  }

  @override
  String toString() => usuario.nome;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Professor && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;
}


