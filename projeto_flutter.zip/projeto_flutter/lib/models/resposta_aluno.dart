
import 'package:gabarito_app/models/prova.dart';

import 'estudante.dart';

class RespostaAluno {
  final int id;
  final Estudante aluno;
  final Prova prova;
  final String numeroQuestao;
  final String alternativaEscolhida;
  final bool correta;

  RespostaAluno({
    required this.id,
    required this.aluno,
    required this.prova,
    required this.numeroQuestao,
    required this.alternativaEscolhida,
    required this.correta,
  });

  factory RespostaAluno.fromJson(Map<String, dynamic> json) {
    return RespostaAluno(
      id: json["id"] ?? 0,
      aluno: Estudante.fromJson(json["aluno"]),
      prova: Prova.fromJson(json["prova"]),
      numeroQuestao: json["numeroQuestao"] ?? "",
      alternativaEscolhida: json["alternativaEscolhida"] ?? "",
      correta: json["correta"] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "aluno": aluno.toJson(),
      "prova": prova.toJson(),
      "numeroQuestao": numeroQuestao,
      "alternativaEscolhida": alternativaEscolhida,
      "correta": correta,
    };
  }

  @override
  String toString() => 'RespostaAluno {id: $id, aluno: ${aluno.nome}, questao: $numeroQuestao, correta: $correta}';

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is RespostaAluno && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;
}


