
import 'package:gabarito_app/models/tipo_usuario.dart';

class Usuario {
  final int id;
  final String senha;
  final TipoUsuario tipoUsuario;
  final String nome;
  final String telefone;
  final String cpf;
  final String email;
  final String? token; // Adicionado para compatibilidade com o login

  Usuario({
    required this.id,
    required this.senha,
    required this.tipoUsuario,
    required this.nome,
    required this.telefone,
    required this.cpf,
    required this.email,
    this.token,
  });

  factory Usuario.fromJson(Map<String, dynamic> json) {
    return Usuario(
      id: json['id'] ?? 0,
      senha: json['senha'] ?? '',
      tipoUsuario: TipoUsuario.fromJson(json['tipoUsuario']),
      nome: json['nome'] ?? '',
      telefone: json['telefone'] ?? '',
      cpf: json['cpf'] ?? '',
      email: json['email'] ?? '',
      token: json['token'], // Pode ser nulo se não for retornado no login
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'senha': senha,
      'tipoUsuario': tipoUsuario.toJson(),
      'nome': nome,
      'telefone': telefone,
      'cpf': cpf,
      'email': email,
      'token': token,
    };
  }

  // Método para verificar se é professor
  bool get isTeacher => tipoUsuario.descricao == 'PROFESSOR';
  
  // Método para verificar se é administrador
  bool get isAdmin => tipoUsuario.descricao == 'ADMINISTRADOR';

  @override
  String toString() => nome;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Usuario && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;

  String? get cargo => null;
}


