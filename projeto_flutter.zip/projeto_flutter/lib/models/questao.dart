import 'package:gabarito_app/models/prova.dart';

class Questao {
  final int id;
  final String numero;
  final double pontuacao;
  final String alternativaCorreta;
  final Prova prova;

  Questao({
    required this.id,
    required this.numero,
    required this.pontuacao,
    required this.alternativaCorreta,
    required this.prova,
  });

  factory Questao.fromJson(Map<String, dynamic> json) {
    return Questao(
      id: json["id"] ?? 0,
      numero: json["numero"] ?? "",
      pontuacao: (json["pontuacao"] ?? 0.0).toDouble(),
      alternativaCorreta: json["alternativaCorreta"] ?? "",
      prova: Prova.fromJson(json["prova"]),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "numero": numero,
      "pontuacao": pontuacao,
      "alternativaCorreta": alternativaCorreta,
      "prova": prova.toJson(),
    };
  }

  @override
  String toString() => 'Questao $numero';

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Questao && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;
}


