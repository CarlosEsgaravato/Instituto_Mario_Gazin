import 'package:gabarito_app/models/questao.dart';


import 'disciplina.dart';

class Prova {
  final int id;
  final DateTime data;
  final Disciplina disciplina;
  final List<Questao> questoes;

  Prova({
    required this.id,
    required this.data,
    required this.disciplina,
    required this.questoes,
  });

  factory Prova.fromJson(Map<String, dynamic> json) {
    var questoesJson = json['questoes'] as List? ?? [];
    List<Questao> questoes = questoesJson
        .map((questao) => Questao.fromJson(questao))
        .toList();

    return Prova(
      id: json['id'] ?? 0,
      data: DateTime.parse(json['data'] ?? DateTime.now().toIso8601String()),
      disciplina: Disciplina.fromJson(json['disciplina']),
      questoes: questoes,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'data': data.toIso8601String(),
      'disciplina': disciplina.toJson(),
      'questoes': questoes.map((q) => q.toJson()).toList(),
    };
  }

  @override
  String toString() => 'Prova ${id} - ${disciplina.nome}';

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Prova && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;
}


